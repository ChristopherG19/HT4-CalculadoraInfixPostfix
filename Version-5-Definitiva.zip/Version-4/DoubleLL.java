/**
 * UVG-Algoritmos y Estructura de datos-Seccion 10
 * Catedrático: Douglas Barrios
 * @author Christopher García, 20541
 * @author Maria Fernanda Argueta, 20458 
 * @version 4
 * Referencias de código en el módulo de canvas de listas
 */

 /**
  * Clase DoubleLL que extiende de List
  * DoubleLinkedList como funcionamiento
  */
public class DoubleLL<E> extends List<E>{

    /**
     * Instancias
     */
   protected NodoDoble<E> Head;
   protected NodoDoble<E> Tail;
   protected int CuentaFD;

   /**
    * Constructor para darles un valor inicial a las instancias
    */
    public DoubleLL(){
        Head = null;
        Tail = null;
        CuentaFD = 0;
    }

    /**
     * Método push
     * @param dato: Recibe el dato que se quiere agregar
     */
   @Override
   public void push(E dato){
       Head = new NodoDoble<E>(dato, Head, Tail);
       if(Tail == null){
           Tail = Head;
       }
       CuentaFD++;
   }
    /**
     * Método pop
     * @param dato: Recibe el dato que se quiere remover
     * @return E: Dato que se removió
     */
   @Override
   public E pop(){

    NodoDoble<E> DatoTemp = Head;
    Head = Head.Siguiente();
    CuentaFD--;
    return DatoTemp.Info();

   }

   /**
     * Método size
     * @return size: Tamaño del almacen
     */
   @Override
   public int size(){
       return CuentaFD;
   }

}
