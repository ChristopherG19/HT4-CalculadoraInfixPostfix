/**
 * UVG-Algoritmos y Estructura de datos-Seccion 10
 * Catedrático: Douglas Barrios
 * @author Christopher García, 20541
 * @author Maria Fernanda Argueta, 20458 
 * @version 4
 */

/**
 * Calculadora
 * Inicio de la clase Calculadora que implementa la interface CalculadoraGeneral
 */
public class Calculadora{

    /**
     * Atributos de la clase
     */
    int A = 0;
    int B = 0;
    int Resu = 0;
    String OperandoF;

    /**
     * Constructor
     */
    public Calculadora(){
    }

    /**
     * Método para realizar las operaciones de la expresión PostFix
     * @param operacion: Recibe un string que contiene la expresión PostFix
     * @param Operandos: Recibe un Stack que contiene los signos
     * @param Operadores: Recibe un Stack que contiene los números
     * @return: Retorna el resultado en forma de String
     */
    public String Operaci(String operacion, StackC<String> Operandos, StackC<Integer> Operadores) {

        /**
         * Instancias
         */
        StackC<Integer> Num = Operadores;
        StackC<String> Sig = Operandos;
        Resu = 0;

        /**
         * Ciclo for para separar la operacion por carácteres
         */
        for(int i=0; i < operacion.length();i++){
            char unico = operacion.charAt(i);
            String Res = String.valueOf(unico);

            /**
             * Si encuentra un signo lo agrega al Stack de signos
             */
            if (Res.equals("+") || Res.equals("-") ||
                Res.equals("*") || Res.equals("/") || 
                Res.equals("^")){
                Sig.push(Res);
            } else {
                /**
                 * Try-catch para convertir los numeros del String en int y en 
                 * dado caso encontrar un espacio vacío no tomarlo en cuenta
                 */
                try {
                    int nu = Integer.parseInt(Res);
                    Num.push(nu);
                } catch (Exception e) {
                    System.out.println("\n|-------------------|");
                    System.out.println("|-----Resultados----|");
                    System.out.println("|-------------------|\n");
                }
            }

            /**
             * Se verifica que hayan los signos y números necesarios para
             * calcular el resultado
             */
            if (Num.size() >= 2 && Sig.size() >= 1){
                
                /**
                 * Se realiza un pop de los dos números que se ingresaron de último 
                 * y el signo que los acompaña
                 */
                A = Num.pop();
                B = Num.pop();
                OperandoF = Sig.pop();

                /**
                 * Se verifica el tipo de signo y se realiza la operación
                 * respetando el orden de los números
                 */
                if (OperandoF.equals("+")){
                    Resu = A + B;
                } else if (OperandoF.equals("-")){
                    Resu = B - A;
                } else if (OperandoF.equals("*")){
                    Resu = A * B;
                } else if (OperandoF.equals("/")){
                    Resu = B / A;
                } else if (OperandoF.equals("^")){
                    Resu = (int)Math.pow(B, A);
                }

                /**
                 * Se guarda el resultado
                 */
                Num.push(Resu);
            }
        }
        /**
         * Se convierte a String el resultado y se retorna
         */
        String Respuesta = String.valueOf(Resu);
        return Respuesta;
    }

}