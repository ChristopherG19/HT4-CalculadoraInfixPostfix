/**
 * UVG-Algoritmos y Estructura de datos-Seccion 10
 * Catedrático: Douglas Barrios
 * @author Christopher García, 20541
 * @author Maria Fernanda Argueta, 20458 
 * @version 4
 */

/**
 * Clase NodoDoble necesaria para que la 
 * clase DoubleLL funcione correctamente
 */
public class NodoDoble<E> {

    /**
     * Instancias
     */
    protected NodoDoble<E> ElementoB;
    protected NodoDoble<E> ElementoA;
    protected E Dat;

    /**
     * Constructor
     * @param dato: Recibe la información de un dato
     * @param B: Recibe el elemento posterior 
     * @param A: Recibe el elemento anterior
     */
    public NodoDoble(E dato, NodoDoble<E> B, NodoDoble<E> A) {

        /**
         * Se asignan los valores a las instancias creadas
         */
        Dat = dato;
        ElementoB = B;
        if (ElementoB != null){
            ElementoB.ElementoA = this;
            ElementoA = A;
        }

        if(ElementoA != null){
            ElementoA.ElementoB = this;
        }
        
    }

    /**
     * Constructor 2, para crear un NodoDoble inicial
     * @param dat
     */
    public NodoDoble(E dat){
        this(dat, null, null);
    }

    /**
     * Método Siguiente
     * @return: Dato siguiente en comparación a otro dato
     */
    public NodoDoble<E> Siguiente(){
        return ElementoB;
    }

    /**
     * Método SetSiguiente
     * @param SigEl: Dato con el que se reemplazará el dato siguiente
     */
    public void setSiguiente(NodoDoble<E> SigEl){
        ElementoB = SigEl;
    }

    /**
     * Método Info
     * @return: Información del dato al que está relacionado
     */
    public E Info(){
        return Dat;
    }

    /**
     * Método SetInfo
     * @param NuevaInfo: Información con la que se sustituirá la información antigua de un dato
     */
    public void SetInfo(E NuevaInfo){
        Dat = NuevaInfo;
    }

    /**
     * Método AnteriorDato
     * @return NodoDoble<E>: Dato anterior a un dato
     */
    public NodoDoble<E> AnteriorDato(){
        return null;
    }

}
