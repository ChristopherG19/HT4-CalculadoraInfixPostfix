/**
 * UVG-Algoritmos y Estructura de datos-Seccion 10
 * Catedrático: Douglas Barrios
 * @author Christopher García, 20541
 * @author Maria Fernanda Argueta, 20458 
 * @version 4
 */

 /**
  * Imports
  */
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.Test;

/**
 * Inicio de clase JUnit que muestra las pruebas unitarias del proyecto
 */
public class JUnit {
 
    /**
     * Test#1: Se comprueba la clase y patrón de diseño Singleton.
     * Se llama al método que comprueba la existencia de una sola calculadora y también
     * el método que comprueba que se creo o no
     */
    @Test
    public void TestSingleton(){


        System.out.println();
        Calculadora c = new Calculadora();
        System.out.println(c);
        Calculadora c2 = new Calculadora();
        System.out.println(c2 + "\n");

        /**
         * Se llama el método que comprueba la existencia y se imprime este valor 
         * con dos instancias diferentes
         */
        SingleCalcu calcu = SingleCalcu.getInstance();
        System.out.println(calcu);
        SingleCalcu calcu2 = SingleCalcu.getInstance();
        System.out.println(calcu2 + "\n");

        /**
         * La finalidad de hacer esto, se observa en la consola...
         * Se puede observar que si se instancian calculadoras sin utilizar la clase
         * Singleton se crean tantas como se solicite y todas distintas, sin embargo
         * al utilizar Singleton podemos observar que a pesar de ser dos instancias
         * distintas Singleton comprueba que solo se crea una instancia y siempre se refiere
         * a la misma.
         */

        /**
         * Mensaje de comprobación
         */
        System.out.println("Se han creado las instancias de calculadora");

        /**
         * Se llama al método que comprueba mediante un boolean si se creó una calculadora
         * luego de llamar al método verificador, y se espera un true que signifique que ya está 
         * creado
         */
        assertEquals(SingleCalcu.Comprobacion(), true);
        System.out.println("Si lees esto, el test funcionó correctamente");
    }

    /**
     * Test#2: Se comprueba que Factory funciona correctamente
     * escogiendo el tipo de pila de acuerdo a la necesidad
     */
    @Test
    public void TestStacks(){

        /**
         * Clases para comprobación
         * 
         * 1 = StackVector
         * 2 = StackArrayL
         * 4 = SingleLL
         * 5 = DoubleLL
         */

        /**
         * Se crea una instancia de Factory
         * y se llama al método que selecciona el tipo de pila 
         * dependiendo de la decisión del usuario, en este caso
         * se hace manual cambiando el valor de eleccion
         */

        FactoryEleccion Seleccionador = new FactoryEleccion();
        int eleccion = 1;
        StackC<Integer> Num = Seleccionador.getStackN(eleccion); 
        StackC<String> Sig = Seleccionador.getStackS(eleccion); 

        /**
         * Se comprueba que tanto para el Stack de Numeros como 
         * de signos se cree una pila proveniente de la misma clase
         * que comprobaría se crean pilas del mismo tipo
         */

        /**
         * Si eleccion es igual a 1, utilizar estos:
         */

        assertEquals(Num.getClass().toString(), "class StackVector");
        assertEquals(Sig.getClass().toString(), "class StackVector");

        /**
         * Si eleccion es igual a 2, utilizar estos:
         */

        // assertEquals(Num.getClass().toString(), "class StackArrayL");
        // assertEquals(Sig.getClass().toString(), "class StackArrayL");

         /**
         * Si eleccion es igual a 4, utilizar estos:
         */

        // assertEquals(Num.getClass().toString(), "class SingleLL");
        // assertEquals(Sig.getClass().toString(), "class SingleLL");

        /**
         * Si eleccion es igual a 4, utilizar estos:
         */

        // assertEquals(Num.getClass().toString(), "class DoubleLL");
        // assertEquals(Sig.getClass().toString(), "class DoubleLL");

        /**
         * Si eleccion es igual a 3 u otro número, fallará el test ya que 
         * el valor retorna por el método es null y se explica a detalle
         * en el Java Test Report
         */
        System.out.println("Si lees esto, el test funcionó correctamente");
    }

    /**
     * Test#3: Se comprueba que la conversión de expresiones de 
     * infix a postfix funciona correctamente
     */
    @Test
    public void ConversionInPos(){

        /**
         * Se llama al método existente en el Main que realiza esta conversión
         * y se le da como parámetro una operación infix, la "conversión" se
         * guarda en un String que se comprueba con assertEquals más adelante
         */
        String Conversion = MainDriver.ChangeTypeOperation("(1+1)*2");
        String Conversion2 = MainDriver.ChangeTypeOperation("6+2^3");
        String Conversion3 = MainDriver.ChangeTypeOperation("1+2*5");
        String Conversion4 = MainDriver.ChangeTypeOperation("(9*2)-1+5");

        /**
         * Se comprueba que la expresión se encuentra en forma postfix luego 
         * de la conversión, si se ejecuta este Test funcionará correctamente
         * lo que indica que la conversión se hizo de manera correcta. Si se cambia 
         * uno de los valores esperados el test fallará.
         */
        assertEquals(Conversion, "11+2*");
        assertEquals(Conversion2, "623^+");
        assertEquals(Conversion3, "125*+");
        assertEquals(Conversion4, "92*1-5+");

        System.out.println("Si lees esto, el test funcionó correctamente");
    }
}
