/**---------------------------------------
 Christopher Garcia-20541
 3er semestre - Ciclo 1
 Algoritmos y estructura de datos
 @Version 3.0 5/02/2021
 ---------------------------------------*/
/**
 * CalculadoraGeneral
 * Inicio de la interface CalculadoraGeneral
 */
public interface CalculadoraGeneral {
    /**
     * Operacion calculo que opera la linea en el documento txt
     */
    String Calculo(String operacion);

}