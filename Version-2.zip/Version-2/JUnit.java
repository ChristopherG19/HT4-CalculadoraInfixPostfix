/**
 * UVG-Algoritmos y Estructura de datos-Seccion 10
 * Catedrático: Douglas Barrios
 * @author Christopher García, 20541
 * @author Maria Fernanda Argueta, 20458 
 * @version 1
 */

 /**
  * Imports
  */
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.Test;

/**
 * Inicio de clase JUnit que muestra las pruebas unitarias del proyecto
 */
public class JUnit {
 
    /**
     * Test#1: Se comprueba la clase y patrón de diseño Singleton.
     * Se llama al método que comprueba la existencia de una sola calculadora y también
     * el método que comprueba que se creo o no
     */
    @Test
    public void TestSingleton(){


        System.out.println();
        Calculadora c = new Calculadora();
        System.out.println(c);
        Calculadora c2 = new Calculadora();
        System.out.println(c2 + "\n");


        /**
         * Se llama el método que comprueba la existencia y se imprime este valor 
         * con dos instancias diferentes
         */
        SingleCalcu calcu = SingleCalcu.getInstance();
        System.out.println(calcu);
        SingleCalcu calcu2 = SingleCalcu.getInstance();
        System.out.println(calcu2 + "\n");

        /**
         * La finalidad de hacer esto, se observa en la consola...
         * Se puede observar que si se instancian calculadoras sin utilizar la clase
         * Singleton se crean tantas como se solicite y todas distintas, sin embargo
         * al utilizar Singleton podemos observar que a pesar de ser dos instancias
         * distintas Singleton comprueba que solo se crea una instancia y siempre se refiere
         * a la misma.
         */

        /**
         * Mensaje de comprobación
         */
        System.out.println("Se han creado las instancias de calculadora");

        /**
         * Se llama al método que comprueba mediante un boolean si se creó una calculadora
         * luego de llamar al método verificador, y se espera un true que signifique que ya está 
         * creado
         */
        assertEquals(SingleCalcu.Comprobacion(), true);

    }


    

}
